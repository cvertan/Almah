package allmahVer4;

public class OperatorLink {
private String label;
private int typ;
	public OperatorLink(String s,int t) {
		label=s;
		typ=t;
	}
  public String toString() {
	  return label;
  }
  public int getTyp() {
	  return typ;
  }
}
