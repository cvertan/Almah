package allmahVer4;
import java.util.ArrayList;
import java.awt.Color;
public class ComponentElement {
	
	Color c;
	ArrayList<GlyphElementNode> elem;
	
	public ComponentElement(Color c,  ArrayList<GlyphElementNode> e) {
		
		this.c=c;
		elem=new ArrayList<GlyphElementNode>();
		for(int i=0;i<e.size();i++) {
			elem.add(e.get(i));
		}
	}
	
	public Color getcolor() {
		return c;
	}
	
	public ArrayList<GlyphElementNode> getElements(){
		return elem;
	}
	/*public String encodeComponentColor() {
		String hex=String.format("#%02x%02x%02x", c.getRed(), c.getGreen(), c.getBlue());
		
		return this.getId()+"*"+hex;
	}*/

}
