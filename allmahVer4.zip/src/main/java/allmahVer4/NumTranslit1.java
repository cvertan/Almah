package allmahVer4;
import java.util.ArrayList;
import java.util.Map;

public class NumTranslit1 extends TreeNode {
	String id;
	ArrayList<NT1Element> elem;
	ArrayList<String> compon;
	ArrayList<String> nt2;
	AllmahGUI tag;
	public NumTranslit1(String id,AllmahGUI tag) {
		super(1);
		this.id=id;
		elem=new ArrayList<NT1Element>();
		compon=new ArrayList<String>();
		nt2=new ArrayList<String>();
		this.tag=tag;
	}
	public String calculateLabel() {
		String aux=""; int n=0;
		ArrayList<Object> o=tag.hb.get((tag.mhb.get(this.getParent())).intValue()).getTeile();
		for (int i=0;i<o.size();i++) {
			//System.out.println("Object class Name "+ o.getClass().getName());
			if(o.get(i).getClass().getName().contains("Glyph")) {
				aux=aux+elem.get(n).getLabel();n=n+1;
			}
			else if(o.get(i).getClass().getName().contains("Operator")) {
				aux=aux+((OperatorLink)o.get(i)).toString();
			}
			else aux=aux+o.get(i).toString();
		}
		return aux;
	}
	
	public ArrayList<String> getCompon(){
		return compon;
	}
	public void generateNT2() {
		ArrayList<NT2Element> n2=new ArrayList<NT2Element>();
		for (int i=0;i<elem.size();i++) {
			n2.add(new NT2Element(elem.get(i)));
		}
		NumTranslit2 nt2=new NumTranslit2(id+">"+"NT2_0",tag);
		nt2.setNT2Elements(n2);
		tag.nt2.add(nt2);
		
		tag.mnt2.put(nt2.getId(),new Integer(tag.nt2.size()-1));
		this.nt2.add(nt2.getId());
		nt2.generateGT1s();
	}
	public NumTranslit1 copy() {
		NumTranslit1 aux=new NumTranslit1(id,tag);
		for (int i=0;i<this.elem.size();i++) {
			aux.getElements().add(elem.get(i));
		}
		return aux;
	}
	public String getParent() {
		return id.substring(0,id.lastIndexOf(">"));
	}
	public void setId(String s) {
		this.id=s;
	}

	
	public String getId() {
		return id;
	}
	public AllmahGUI getTagInterf() {
		return tag;
	}
	

	public  ArrayList<TreeNode> listNodes(){
		 ArrayList <TreeNode> t=new ArrayList<TreeNode>();
		 if(nt2.size()>0) {
		 for(int i=0;i<nt2.size();i++) {
		       t.add(tag.nt2.get((tag.mnt2.get(nt2.get(i)).intValue())));
		 }
		 }
		 return t;
	 }
	public ArrayList<NT1Element> getElements(){
		return elem;
	}
	

}
