package allmahVer4;
import java.util.ArrayList;
public class GT1Element {
private String label;
private NT2Element parent;
private Reading reading;

	public GT1Element(NT2Element n, Reading r) {
		parent=n;
		reading=r;
		if (r!=null)
		     label=r.getReading();		
		else label=n.getLabel();
	}
	
	public GT1Element copy() {
		GT1Element x= new GT1Element(parent, reading);
		return x;
	}
	

	public void setLabel(String s) {
		label=s;
		
	}
	public String getLabel() {
		return label;
	}
}
