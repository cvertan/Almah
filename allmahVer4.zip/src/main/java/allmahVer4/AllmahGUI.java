package allmahVer4;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Paint;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Random;
import java.awt.event.*;

import javax.swing.tree.DefaultTreeModel;
import edu.uci.ics.jung.graph.*;
import edu.uci.ics.jung.visualization.GraphZoomScrollPane;
import com.google.common.base.Function;
import com.google.common.base.Functions;
import org.jsoup.*;
import edu.uci.ics.jung.algorithms.layout.Layout;
import edu.uci.ics.jung.algorithms.layout.StaticLayout;
import edu.uci.ics.jung.algorithms.layout.TreeLayout;
import edu.uci.ics.jung.algorithms.shortestpath.MinimumSpanningForest2;
import edu.uci.ics.jung.graph.DelegateForest;
import edu.uci.ics.jung.graph.DelegateTree;
import edu.uci.ics.jung.graph.Forest;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;
import edu.uci.ics.jung.visualization.control.GraphMouseListener;
import edu.uci.ics.jung.visualization.control.ModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ScalingControl;
import edu.uci.ics.jung.visualization.decorators.EdgeShape;
import edu.uci.ics.jung.visualization.decorators.ToStringLabeller;
import edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position;

import javax.swing.tree.*;
import javax.swing.*;
import javax.swing.event.*;
import info.textgrid.clients.SearchClient;
import info.textgrid.clients.tgsearch.SearchQueryBuilder;
import info.textgrid.namespaces.middleware.tgsearch.Response;
import info.textgrid.namespaces.middleware.tgsearch.ResultType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AllmahGUI extends JFrame implements ActionListener{
	private JDesktopPane desk;
	private String versTool;
	private Random randomGenerator;
	private Font typFont1=new Font("Sans Serif",Font.PLAIN,16);
	private Font typFont1Menu1=typFont1.deriveFont(Font.BOLD,18);
	private Color mainFrameColor=Color.LIGHT_GRAY;
	private JMenuItem openNewLocalFile, openNewGridFile, openAnnotatedFile;
	
	protected HyerogliphenDocument doc;
	protected ArrayList<DocumentReading> docr;
	protected ArrayList<HieroglyphenBlock> hb;
	protected ArrayList<NumTranslit1> nt1;
	protected ArrayList<NumTranslit2> nt2;
	protected ArrayList<GraphTranslit1> gt1;
	//protected ArrayList<GraphTranslit2> gt2;
	//protected ArrayList<PhonTranslit> pt;
	protected Map <String,Integer> mdocr=new HashMap<String,Integer>();
	protected Map <String,Integer> mhb=new HashMap<String,Integer>();
	protected Map <String,Integer> mnt1=new HashMap<String,Integer>();
	protected Map <String,Integer> mnt2=new HashMap<String,Integer>();
	protected Map <String,Integer> mgt1=new HashMap<String,Integer>();
	protected Map <String,Integer> mgt2=new HashMap<String,Integer>();
	protected Map <String,Integer> mpt=new HashMap<String,Integer>();
	public AllmahGUI() {
		super("Almah - Annotation of classical Maya Documents");
		String s="";
		 try{
			   File jarDir = new File(ClassLoader.getSystemClassLoader().getResource(".").getPath());
			   s=System.getProperty("java.class.path");
			   int pT=s.indexOf("allmah");
			   versTool=s.substring(pT+6);
			  
			   if(!(versTool.indexOf("bin")>=0)) { 
			       pT=versTool.indexOf(".jar");
			   }
			   else   pT=versTool.indexOf("\\target");
		versTool=versTool.substring(0,pT);
		   }
          catch(Exception e){}
		 randomGenerator = new Random();
		 this.setTitle(this.getTitle()+" "+versTool);
		   System.out.println("Version Tool "+versTool);	
		   buildInterface();
	}
	
	public JDesktopPane getDesktop() {
		return desk;
	}
	public void addChild(ChildFrame child, int x, int y,int w,int h){
		 child.setLocation(x,y);
		child.setSize(w,h);
		 child.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		 desk.add(child);
		 child.setVisible(true);
		}
	public void buildInterface() {	  
	    desk=new JDesktopPane();
		desk.putClientProperty("JDesktopPane.dragMode", "outline");
		desk.setAutoscrolls(true);
		desk.setDesktopManager(new DefaultDesktopManager());
		desk.setAutoscrolls(true); desk.setFont(typFont1Menu1);	
		setContentPane(desk);
	    setResizable(true);
	    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	    setSize(screenSize.width, screenSize.height);
	    setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowClosingAdapter(true));
	    addComponentListener(new ComponentAdapter() {  
	    	public void componentResized(ComponentEvent e)  
	    	{  
	    	mainWin_componentResized(e);  
	    	}  
	    	   
	    	});  
	    JMenuBar menubar=new JMenuBar();
	    menubar.add(createFileMenu());
	    setJMenuBar(menubar);
	    
	  show();
	}
	 public JMenu createFileMenu(){
	 	   JMenu dateien=new JMenu ("File");
	 	  dateien.setFont(typFont1);
	 	 dateien.setMnemonic('F');
	      JMenu openFile=new JMenu("Open");
	                      openFile.setMnemonic('O');
	                      openFile.setFont(typFont1);
	         openNewLocalFile=new JMenuItem ("Open new local file");
	         openNewLocalFile.setFont(typFont1);
	          openNewLocalFile.addActionListener(this);
	          openFile.add(openNewLocalFile);
	          openNewGridFile=new JMenuItem ("Open new grid file");
		         openNewGridFile.setFont(typFont1);
		          openNewGridFile.addActionListener(this);
		          openFile.add(openNewGridFile);
		          openAnnotatedFile=new JMenuItem ("Open annotated file");
			         openAnnotatedFile.setFont(typFont1);
			          openAnnotatedFile.addActionListener(this);
			          openFile.add(openAnnotatedFile);
			          dateien.add(openFile);
	 	   return dateien;
	 }	   
	 public void actionPerformed(ActionEvent event){
	 		
	 		String e=event.getActionCommand();
	 		if (e.equals("Open new local file")){
	 			LocalReadFile lrf=new LocalReadFile(this);
	 			
	 			MayaDocumentParser parser=new MayaDocumentParser(this,lrf.getChoosedFile(),typFont1);
	 			parser.getMayaDocumentTitle();
	 			hb=parser.getMayaDocumentParts();
	 			docr=new ArrayList<DocumentReading>();
	 			gt1=new ArrayList<GraphTranslit1>();
	 			nt2=new ArrayList<NumTranslit2>();
	 			nt1=new ArrayList<NumTranslit1>();
	 			
	 			doc=new HyerogliphenDocument(parser.docID,this);
	 			
	 			DocumentReading dr=new DocumentReading(doc.getId(),this);
	 			
	 			docr.add(dr);mdocr.put(dr.getId(),new Integer(0));
	 			doc.getDocReadings().add(dr.getId());
	 			for (int i=0;i<hb.size();i++) {
	 				mhb.put(hb.get(i).getBlockID(),new Integer(i));
	 				hb.get(i).generateNT1();
	 				dr.getBlocks().add(hb.get(i).getBlockID());
	 			}	
	 			
	 			
	 			ChildFrame  mainwin= new ChildFrame("Annotate "+ parser.getMayaDocumentTitle() ,Color.gray,WindowConstants.DISPOSE_ON_CLOSE);
				Container cfin=mainwin.getContentPane();
				JTree blockTree=builtAnnTree();
					JScrollPane sc =new JScrollPane(blockTree);
					cfin.add(sc);
				mainwin.pack();
				mainwin.moveToFront();
				this.addChild(mainwin,20,20,desk.getWidth()-400,desk.getHeight()-100);
	 		}
	 		else if (e.equals("Open new grid file")){
	 			
	 			TextGridReadFile tgr=new TextGridReadFile();
	 			tgr.fileList();
	 		}
	 }
	private void mainWin_componentResized(ComponentEvent e)  
	{  
	//System.out.println("\nmainWin_componentResized(ComponentEvent e) called.");  
	// TODO: Add any handling code here  
	   
	}
	private VisualizationViewer<GlyphNode,OperatorLink> getHBGraphViewer(Graph<GlyphNode,OperatorLink> g, Graph<GlyphNode,OperatorLink> t){
		 
        Function<GlyphNode, Paint> vertexPaint = new Function<GlyphNode, Paint>() {
            public Paint apply(GlyphNode i) {
            	if(i.getTyp().equals("glyph"))
            return Color.GREEN;
            	else if(i.getTyp().equals("segm")) return Color.YELLOW;
            	else return Color.WHITE;
        }
    };
        	 float dash[] = {10.0f};
             final Stroke edgeStroke = new BasicStroke(1.0f, BasicStroke.CAP_BUTT,
                  BasicStroke.JOIN_MITER, 10.0f, dash, 0.0f);
             final Stroke edgeStroke1 = new BasicStroke();
             Function<OperatorLink, Stroke> edgeStrokeTransformer =
                     new Function<OperatorLink, Stroke>() {
                         public Stroke apply(OperatorLink s) {
                        	 if(s.getTyp()==0)
                             return edgeStroke1;
                        	 else   return edgeStroke;
                         }
                     };
                     
                     Function<GlyphNode, java.awt.Shape> vertexSize=
                    		 new Function<GlyphNode, java.awt.Shape>() {
                    	 public java.awt.geom.Ellipse2D.Double apply(GlyphNode s) {
                    		 double width = s.toString().length() * 10.0;
                             return new java.awt.geom.Ellipse2D.Double(-(width/2), -12.5, width, 25);
                         }
                     };
                     Function <OperatorLink, String> edgeLabel=
                         new Function<OperatorLink, String>() {
                         public String apply(OperatorLink e) {
                           if (e.getTyp()==1) 
                             return  e.toString();
                           
                           else return "  ";
                         }
                     };
                     Function <GlyphNode,Font> vertexFont = new Function<GlyphNode,Font>() {
                         public Font apply(GlyphNode e) {
                             Font font = new Font("Sans Serif", Font.BOLD, 16);
                             return font;
                         }
                           };
                   Function <OperatorLink,Font> edgeFont = new Function<OperatorLink,Font>() {
                         public Font apply(OperatorLink e) {
                             Font font = new Font("Sans Serif", Font.BOLD, 18);
                          
                             return font;
                         }
                           };
                      
		MinimumSpanningForest2<GlyphNode,OperatorLink> prim = 
              	new MinimumSpanningForest2<GlyphNode,OperatorLink>(t,
              		new DelegateForest<GlyphNode, OperatorLink>(), DelegateTree.<GlyphNode,OperatorLink>getFactory(),
              		Functions.<Double>constant(8.0));
    
  Forest<GlyphNode,OperatorLink> tree = prim.getForest();
  Layout<GlyphNode,OperatorLink> layout = new TreeLayout<GlyphNode,OperatorLink>(tree); 
      Layout<GlyphNode,OperatorLink> layout1 = new StaticLayout<GlyphNode,OperatorLink>(g, layout);
	layout1 . setSize ( new Dimension (550 , 550) );
			VisualizationViewer<GlyphNode,OperatorLink> vv =
					 new VisualizationViewer<GlyphNode,OperatorLink>(layout1, new Dimension (550 ,550));
			vv.getRenderContext().setVertexLabelTransformer(new ToStringLabeller());
			vv.addGraphMouseListener(new GraphMouseListener() {

 	            @Override
 	            public void graphClicked(Object v, MouseEvent me) {
 	                if (me.getButton() == MouseEvent.BUTTON1 && me.getClickCount() == 1) {
 	                    System.out.println(" clicked "+ v);
 	                }
 	                me.consume();
 	            }

 	            @Override
 	            public void graphPressed(Object v, MouseEvent me) {
 	            }

 	            @Override
 	            public void graphReleased(Object v, MouseEvent me) {
 	            }
 	        });
//  			vv.setGraphMouse(gm);
           //  vv . setPreferredSize ( new Dimension (550 ,550));
         vv.getRenderContext().setEdgeLabelTransformer(edgeLabel);
         vv.getRenderContext().setVertexShapeTransformer(vertexSize);
         vv.getRenderContext().setVertexFillPaintTransformer(vertexPaint);
         vv.getRenderContext().setEdgeStrokeTransformer(edgeStrokeTransformer);
         vv.getRenderContext().setEdgeShapeTransformer(EdgeShape.quadCurve(g));
         vv.getRenderContext().setEdgeFontTransformer(edgeFont);
         vv.getRenderContext().setVertexFontTransformer(vertexFont);
         vv.getRenderContext().setVertexLabelTransformer(new ToStringLabeller());
         // vv.getRenderContext().setEdgeLabelTransformer(new ToStringLabeller());
          vv.getRenderer().getVertexLabelRenderer().setPosition(Position.CNTR);  
          DefaultModalGraphMouse gm = new DefaultModalGraphMouse();
          gm.setMode(ModalGraphMouse.Mode.TRANSFORMING);
          vv.setGraphMouse(gm); 
			return vv;
	}
	public Font getFontInterf() {
		return typFont1;
	}
	 public AllmahGUI getInterf(){
		 return this;
	 }
	 private DefaultTreeModel createTreeModel() {
			AnnotationNode root=new AnnotationNode(doc), node;
			root.explore();
			return new DefaultTreeModel(root);
		}

	 public JTree builtAnnTree() {
			JTree blockTree=new JTree(createTreeModel());
			blockTree.getModel().addTreeModelListener(new TreeModelListener() {
				public void treeStructureChanged(TreeModelEvent e) {
					blockTree.repaint();;
				}
		      public void treeNodesChanged(TreeModelEvent e) {
		    	  blockTree.repaint();
				}
		      public void treeNodesInserted(TreeModelEvent e) {
		    	  ((DefaultTreeModel)blockTree.getModel()).reload();
				}
		      public void treeNodesRemoved(TreeModelEvent e) {
		    	  blockTree.repaint();
				}
			});
			blockTree.setFont(typFont1);
			
			DefaultMutableTreeNode root=(DefaultMutableTreeNode)blockTree.getModel().getRoot();
			blockTree.addTreeExpansionListener(new TreeExpansionListener() {
				public void treeCollapsed(TreeExpansionEvent e) {
					
				}
				public void treeExpanded(TreeExpansionEvent e) {
					
				}
			});
			
			blockTree.addMouseListener( new MouseAdapter() {
				private void myPopupEvent(MouseEvent e) {
		            int x = e.getX();
		            int y = e.getY();
		            JTree tree = (JTree)e.getSource();
		            TreePath path = tree.getPathForLocation(x, y);
		            TreePath[] paths = tree.getSelectionPaths();

	                for (TreePath path1 : paths) {
	                    System.out.println("You've selected: " + path1.getLastPathComponent());
	                }
		            if (path== null)
		                return; 

		            tree.setSelectionPath(path);

		           AnnotationNode obj = ( AnnotationNode)path.getLastPathComponent();
		//    System.out.println(""+obj.getMyTreeNode().getClass());
		            String label = ""+obj.getMyTreeNode().getClass();
		            JPopupMenu popup= new JPopupMenu();
		          //  popup.add(new JMenuItem(label));
		            if (label.equals("class allmahVer4.HieroglyphenBlock")) {
		            	if(((HieroglyphenBlock)obj.getMyTreeNode()).getState()) {
		                  final  JMenuItem menuHbI=new JMenuItem("View Graph Representation");
		                  menuHbI.addActionListener(new ActionListener() {
		                    	public void actionPerformed(ActionEvent e) {
		                    		HieroglyphenBlock currentNode= (HieroglyphenBlock)obj.getMyTreeNode();
		                    		VisualizationViewer<GlyphNode,OperatorLink>	vv=getHBGraphViewer(currentNode.getEntireGraphHB(), currentNode.getTreeGraphHB());
		                    		ChildFrame hbGFrame= new ChildFrame("Graph Representation for "+ Jsoup.parse(obj.getMyTreeNode().getNodeLabel()).text(),Color.BLUE,WindowConstants.DISPOSE_ON_CLOSE);
		                    		 
		                    		   hbGFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		                    		  
		                    	        final GraphZoomScrollPane panel = new GraphZoomScrollPane(vv);
		                    	     
		                    	        Container content =hbGFrame. getContentPane();
		                    		   content.add(panel); 
		                    		   final ScalingControl scaler = new CrossoverScalingControl();
		                    		  scaler.scale(vv, 1.1f, vv.getCenter()); 
		                    		  //scaler.scale(vv, 1.1f, vv.getCenter()); scaler.scale(vv,1.1f, vv.getCenter());
		                    		//   scaler.scale(vv, 1.1f, vv.getCenter()); scaler.scale(vv, 1.1f, vv.getCenter()); scaler.scale(vv,1.1f, vv.getCenter());
		                    		//   hbGFrame.repaint();
		                    		     JButton plus = new JButton("+");
		                    		        plus.addActionListener(new ActionListener() {
		                    		            public void actionPerformed(ActionEvent e) {
		                    		                scaler.scale(vv, 1.1f, vv.getCenter());
		                    		            }
		                    		        });
		                    		        JButton minus = new JButton("-");
		                    		        minus.addActionListener(new ActionListener() {
		                    		            public void actionPerformed(ActionEvent e) {
		                    		                scaler.scale(vv, 1/1.1f, vv.getCenter());
		                    		            }
		                    		        });
		                    		   
		                    		        JPanel scaleGrid = new JPanel(new GridLayout(1,0));
		                    		        scaleGrid.setBorder(BorderFactory.createTitledBorder("Zoom"));

		                    		        JPanel controls = new JPanel();
		                    		        scaleGrid.add(plus);
		                    		        scaleGrid.add(minus);
		                    		        controls.add(scaleGrid);
		                    		       content.add(controls, BorderLayout.SOUTH);
		                    		     
		                    		   hbGFrame.pack();
		                    		   addChild(hbGFrame,800, 10, 500, 600);		
		                    		   hbGFrame.setVisible(true); 
		                    		   hbGFrame.moveToFront();
		                    	}
		                 });
		                    popup.add(menuHbI);
		               
		            }
		                 
		            }
		            else  if (label.equals("class GraphTransit1")) {
		                  final  JMenuItem menuGr2I=new JMenuItem("Insert/Modify Graphical Translit 2");
		                  final  JMenuItem menuGr2D=new JMenuItem("Delete Graphical Translit 2");
		                    popup.add(menuGr2I);
		                    popup.add(menuGr2D);
		                   
		                 
		            }
		            else if (label.equals("class NumTranslit1")) {
		                final JMenuItem defCompon=new JMenuItem("Define Component");
		                final JMenuItem insN2=new JMenuItem("Insert Num Translit.2");
		                final JMenuItem delN2=new JMenuItem("Delete Num Translit.2");
		                popup.add(defCompon);
		                popup.addSeparator();
		                popup.add(insN2);
		                popup.add(delN2);
		                //
		            
		               
		        }
		            popup.show(tree, x, y);
		        }
				 public void mousePressed(MouseEvent e) {
			            if (e.isPopupTrigger()) myPopupEvent(e);
			        }
			        public void mouseReleased(MouseEvent e) {
			            if (e.isPopupTrigger()) myPopupEvent(e);
			        }
			});
			return blockTree;
		}
}
