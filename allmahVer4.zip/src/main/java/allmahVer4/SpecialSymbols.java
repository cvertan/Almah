package allmahVer4;

public interface SpecialSymbols {
    public final String NOT_IDENTIFIABLE_SYMBOL="??";
    public final String ALTERNATIVE_SYMBOL="?";
    public final String GAP="#";
    public final String ASTERIX="*";
    public final String NOT_READABLE="\u2026";
    public final String[] OperatorsSet_L13= {":",".","+","°","^","┌","┐"," ╝","╚ ","╗","╔ ","-"};
    public final String Operators_L13= ":.+°^┌┐╝╚ ╗╔-";

}
