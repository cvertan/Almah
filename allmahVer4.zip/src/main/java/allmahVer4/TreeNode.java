package allmahVer4;
import java.util.ArrayList;
import java.util.Map;
public abstract class TreeNode {
    private String label;
    private int level;
    private boolean finish;
   
	public TreeNode(int n) {
		level=n;
		finish=false;
	}
    public String  getNodeLabel() {
    	String s=calculateLabel();
    	//System.out.println("Node "+s );
    	if( level==1) return "<html> <font color=\"red\"> <b>Num Tr 1: </b> </font>"+s +"</html>";
    	else if( level==2) return "<html> <font color=\"blue\"> <b>Num Tr 2:</b>  </font>"+s +"</html>";
    	else if( level==3) return "<html> <font color=\"gray\"> <b>Graphical Tr 1:  </b></font>"+s +"</html>";
    	else if( level==4) return "<html> <font color=\"black\"> <b>Graphical Tr 2: </b> </font>"+s +"</html>";
    	else return s;
    }
    public void setFinish() {
    	finish=true;
    }
    public boolean getFinish() {
    	return finish;
    }
    public int getLevel() {
    	return level;
    }
    public abstract String calculateLabel();
	 public  abstract ArrayList<TreeNode> listNodes();
	public abstract String getParent();
}
