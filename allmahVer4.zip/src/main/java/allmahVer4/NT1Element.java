package allmahVer4;
import java.util.ArrayList;
public class NT1Element {
private String label;
private GlyphElementNode parent;


	public NT1Element(GlyphElementNode g) {
		label=g.getLabel();
		if (!label.equals("??"))
		     label=process(label); 
		parent=g;
	}
	public NT1Element(GlyphElementNode g, String s) {
		label=s;
		parent=g;
	}
	public NT1Element copy() {
		NT1Element x= new NT1Element(parent);
		x.setLabel(this.label);
		return x;
	}
	public GlyphElementNode  getParent() {
		return parent;
	}
	public String process (String s) {
		String aux=s;
		if (aux.length()>1) {
		if((aux.indexOf("*")==0)||(aux.indexOf("?")==0))aux=aux.substring(1);
		if((aux.indexOf("*")==aux.length()-1)||(aux.indexOf("?"))==aux.length()-1)aux=aux.substring(0,aux.length()-1);
		}
		return aux;
	}
	public void setLabel(String s) {
		label=s;
		
	}
	public String getLabel() {
		return label;
	}
}
