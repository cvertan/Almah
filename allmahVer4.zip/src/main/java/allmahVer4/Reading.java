package allmahVer4;

public class Reading {
 private int confidence;
 private String reading;
 private String typ;
 private boolean state;
	public Reading(String s, int n,String t) {
		reading=s;
	  	confidence=n;	
	  	typ=t;
	  	state=true;
	}
	public Reading(String s, int n,String t,boolean b) {
		reading=s;
	  	confidence=n;	
	  	typ=t;
	  	state=b;
	}
	public String getReading() {
		return reading;
	}
	public int getConfidence() {
		return confidence;
	}
	public String getTyp() {
		return typ;
	}
	public boolean getState() {
		return state;
	}
	public void setState(boolean b) {
		state=b;
	}
	public void setTyp(String s) {
		typ=s;
	}
	public void setReading(String s) {
		reading=s;
	}
	public void setConfidence(int n) {
		confidence=n;
	}

}
