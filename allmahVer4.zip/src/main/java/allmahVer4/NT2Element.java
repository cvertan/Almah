package allmahVer4;
import java.util.ArrayList;
public class NT2Element {
private String label;
private NT1Element parent;


	public NT2Element(NT1Element n) {
		parent=n;
		label=process(n.getLabel());	
		
	}
	
	public NT2Element copy() {
		NT2Element x= new NT2Element(parent);
		x.setLabel(this.label);
		return x;
	}
	public NT1Element getParent(){
		return parent;
	}
	public String process (String s) {
		String aux=s;
		   if (aux.length()>=3) {
			   String x=aux.substring(aux.length()-2);
			   if (x.matches("[a-zA-Z]+")) aux=aux.substring(0,aux.length()-2);
		   }
		return aux;
	}
	public void setLabel(String s) {
		label=s;
		
	}
	public String getLabel() {
		return label;
	}
}
