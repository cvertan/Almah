package allmahVer4;
import java.util.ArrayList;
import java.lang.Integer;
public class DocumentReading extends TreeNode {

	
	private String id;
	private boolean state;
	private ArrayList<String> b;
	private AllmahGUI interf;
	private String parent;
	public DocumentReading( String num, AllmahGUI in) {
		super(0);
		this.interf=in;
		this.id=num+">R"+ interf.docr.size();
		parent=num;
		state=true;
		b=new ArrayList<String>();
	}
	public String calculateLabel() {
		return id.substring(id.indexOf(">")+1);
	}
	public String getParent() {
		return parent;
	}
	public boolean getState() {
		return state;
	}
	public void setState(boolean b) {
		state=b;
	}
	 public  ArrayList<TreeNode> listNodes(){
		 ArrayList <TreeNode> t=new ArrayList<TreeNode>();
		 for(int i=0;i<b.size();i++) {
			 t.add(interf.hb.get(interf.mhb.get(b.get(i)).intValue()));
		 }
		 return t;
	 }	

	public String getId(){
		return id;
	}
	
	public void setId(String s) {
		id=s;
	}
	
	public ArrayList<String> getBlocks() {
		return b;
	}
	public void setBlocks(ArrayList<String> bid) {
		for(int i=0;i<bid.size();i++)
               b.add(bid.get(i));
	}

}
