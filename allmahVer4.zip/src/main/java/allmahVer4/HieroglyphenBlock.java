package allmahVer4;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.HashMap;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.SparseGraph;
import edu.uci.ics.jung.graph.util.EdgeType;
public class HieroglyphenBlock extends TreeNode{
	private String id ;
	private String label;
	private String numerical;
	private boolean state;
	private ArrayList<GlyphElementNode> elemNodes;
	private Graph<GlyphNode,OperatorLink> g ;
	private Graph<GlyphNode,OperatorLink> t; 
	 private String parent;
    private ArrayList<String> ntr1;
    private AllmahGUI interf;
    private ArrayList<Object> teile;
	public HieroglyphenBlock(String readingID, String num, String l, boolean state, AllmahGUI in)  {
		super(0);
		id=readingID+">"+l;
		numerical=num;
		teile=new ArrayList<Object>();
		this.label=l;	
		this.state=state;
		parent=readingID;
		elemNodes= new ArrayList<GlyphElementNode>();
		ntr1=new ArrayList<String>();
		this.interf=in;
	}
	public boolean getState() {
		return state;
	}
	public String getParent() {
		return parent;
	}
	public void setState(boolean b) {
		state=b;
	}
	public String calculateLabel() {
		if (state)
		return "<html><body><b>" +label +"</b>"+ "<br/>"+numerical+"</body></html>";
		else if (numerical.equals("#")) return "<html><body><font color=\"#c4c3d0\"><b>" +label +"</b>"+ "<br/>"+numerical+"</font></body></html>";
		else return "<html><body><font color=\"#c4aead\"><b>" +label +"</b>"+ "<br/>"+numerical+"<br/>ERROR</font></body></html>";
	}
	public String getBlockID() {
		return id;
	}
	 public  ArrayList<TreeNode> listNodes(){
		 ArrayList <TreeNode> t=new ArrayList<TreeNode>();
		 for(int i=0;i<ntr1.size();i++) {
			t.add(interf.nt1.get((interf.mnt1.get(ntr1.get(i))).intValue()));
		 }
		 return t;
	 }	
	 public String getNumLabel() {
		return numerical;
	}
	public String getLabel() {
		return label;
	}
	public ArrayList<GlyphElementNode> getElements(){
		return elemNodes;
	}
	public Graph<GlyphNode,OperatorLink> getEntireGraphHB(){
		return g;
	}
	public Graph<GlyphNode,OperatorLink> getTreeGraphHB(){
		return t;
	}
	public void createGraphStructure(String s, Map<String,ArrayList< Reading>> elements, Map <String, ArrayList<String>>choiceList) {
		String label=s;
		StringTokenizer st=new StringTokenizer(label,SpecialSymbols.Operators_L13,true);
		String elem="";
		g = new SparseGraph<GlyphNode,OperatorLink>();
		 t = new SparseGraph<GlyphNode,OperatorLink>();
		
		ArrayList <GlyphElementNode> glyphElements=new ArrayList<GlyphElementNode>();
		ArrayList <OperatorLink> operators=new ArrayList<OperatorLink>();
		String currentOp="";
		GlyphNode root=new SegmentNode(s,null,"root");
		GlyphNode currentParent=root;
		t.addVertex(currentParent);
		GlyphNode prevNode=null;
		GlyphNode node;
		int noalt=0;
		while (st.hasMoreTokens()) {
		   elem=st.nextToken();
		   if ( Arrays.stream(SpecialSymbols.OperatorsSet_L13).anyMatch(elem::equals))
			{System.out.println("Operator "+elem); operators.add(new OperatorLink(elem,1)); teile.add(operators.get(operators.size()-1));}
		   else { System.out.println("Glyph "+elem);
		               if ((elem.indexOf("[")<0)&&(elem.indexOf("]")<0)){
		            	if(elem.equals("??")) {
		            	
		            		node=new GlyphElementNode(elem,currentParent);   elemNodes.add((GlyphElementNode)node);    	
		            		teile.add(node);
		            	}
		            	else if(elem.equals("?")) {
		            		node=new GlyphElementNode(elem,currentParent); 
		            		System.out.println("ELEM "+ elem+ " "+noalt);
		            		ArrayList<String> alt=choiceList.get("?"+noalt);
		            		for (int j=0;j<alt.size();j++)
		            		((GlyphElementNode)node).getAlternatives().put(alt.get(j),elements.get(alt.get(j)) );
		            		noalt=noalt+1;elemNodes.add((GlyphElementNode)node);   
		            		teile.add(node);
		            	}
		            	else {
		            		System.out.println("Kernel= "+kernel(elem));
		            		node=new GlyphElementNode(elem,currentParent, elements.get(kernel(elem)));
		            		elemNodes.add((GlyphElementNode)node);    	teile.add(node);   
		            	}
		           
		            ( (SegmentNode)  currentParent).getChildrenNodes().add(node);
		               g.addEdge(new OperatorLink("  ",0), currentParent, node, EdgeType.DIRECTED); 
		              t.addEdge(new OperatorLink("  ",0),currentParent,node, EdgeType.DIRECTED); 
		              
		               if (prevNode !=null) {
			                         g.addEdge(operators.get(operators.size()-1),prevNode, node, EdgeType.DIRECTED); 
			                        // System.out.println("Added " + glyphElements.get(glyphElements.size()-1).toString()+currentOp+ elem );
		               }
			                         prevNode=node;
		                   
		               }
		               //
		               else if (elem.indexOf("[")>=0) {
		            	   String aux=elem; int n=1;
		            	   while(aux.indexOf("[")==0) {
		            		    node=new SegmentNode("[     ]",currentParent,"segm");teile.add("[");
		            		    ( (SegmentNode)  currentParent).getChildrenNodes().add(node);
		            		   if((prevNode!=null))  {
		            			   g.addEdge(operators.get(operators.size()-1),prevNode, node, EdgeType.DIRECTED); 
		            			  
		            		   }
		            		   prevNode=node;
		            		   g.addEdge(new OperatorLink("  ",0),currentParent, node, EdgeType.DIRECTED); 
		            	  t.addEdge(new OperatorLink("  ",0),currentParent, node, EdgeType.DIRECTED); 
		            		
		            		  
		            		   currentParent=node;
		            		   aux=aux.substring(1);n=n+1;
		               }
		            	   if(aux.equals("??")) {
				            	
			            		node=new GlyphElementNode(aux,currentParent);       	elemNodes.add((GlyphElementNode)node);    teile.add(node);	                
			            	}
		            	   else if(aux.equals("?")) {
			            		node=new GlyphElementNode(aux,currentParent); teile.add(node);
			            		System.out.println("ELEM "+ elem+ " "+noalt);
			            		ArrayList<String> alt=choiceList.get("?"+noalt);
			            		for (int j=0;j<alt.size();j++)
			            		((GlyphElementNode)node).getAlternatives().put(alt.get(j),elements.get(alt.get(j)) );
			            		elemNodes.add((GlyphElementNode)node);    	   
			            		noalt=noalt+1;
			            	}
		            	   else  {node=new GlyphElementNode(aux,currentParent,elements.get(kernel(aux))); teile.add(node); elemNodes.add((GlyphElementNode)node);  }
		            	    ( (SegmentNode)  currentParent).getChildrenNodes().add(node);
		            	    prevNode=node;
		            	    g.addEdge(new OperatorLink("  ",0),currentParent, node, EdgeType.DIRECTED); 
		            	 t.addEdge(new OperatorLink("  ",0),currentParent, node, EdgeType.DIRECTED); 
		            	   	   
		            	 
		               }
		               else if(elem.indexOf("]")>=0) {
		            	   String aux=elem;
		            	   if(elem.substring(0,elem.indexOf("]")).equals("??")) {
				            	
			            		node=new GlyphElementNode(elem.substring(0,elem.indexOf("]")),currentParent);       	   elemNodes.add((GlyphElementNode)node);  
			            		teile.add(node);
			            	}
		            	   else if(elem.substring(0,elem.indexOf("]")).equals("?")) {
			            		node=new GlyphElementNode(elem.substring(0,elem.indexOf("]")),currentParent); 
			            		System.out.println("ELEM "+ elem+ " "+noalt);
			            		ArrayList<String> alt=choiceList.get("?"+noalt);
			            		for (int j=0;j<alt.size();j++)
			            		((GlyphElementNode)node).getAlternatives().put(alt.get(j),elements.get(alt.get(j)) );
			            		noalt=noalt+1;elemNodes.add((GlyphElementNode)node);    	  teile.add(node); 
			            	}
		            	   else {node=new GlyphElementNode(elem.substring(0,elem.indexOf("]")),currentParent,elements.get(kernel(elem.substring(0,elem.indexOf("]")))));
		            	   elemNodes.add((GlyphElementNode)node); teile.add(node);
		            	   }
		            	   ( (SegmentNode)  currentParent).getChildrenNodes().add(node);
		            	   g.addEdge(new OperatorLink("  ",0),currentParent, node, EdgeType.DIRECTED);
		             t.addEdge(new OperatorLink("  ",0),currentParent, node, EdgeType.DIRECTED);
		           
		            	 
		            	   g.addEdge(operators.get(operators.size()-1),prevNode, node, EdgeType.DIRECTED); 
		            	   
		            	   while(aux.indexOf("]")>0) {
		            		   prevNode=currentParent;  node=currentParent;;currentParent=node.getParent();
		            		  teile.add("]");
		            		  if(aux.substring(aux.indexOf("]")).length()>1) {
		            		  aux=aux.substring(0,aux.indexOf("]"))+aux.substring(aux.indexOf("]")+1);
		            		   
		            		  }
		            		  else  aux=aux.substring(0,aux.indexOf("]"));
		            	   }
		               }	
		   }
		}
   
	}
	public ArrayList<Object> getTeile(){
		return teile;
	}
	private String kernel(String s) {
		String aux=s;
		  if( s.equals("??")) return"";
		  else if (s.equals("?")) return "choice";
		  else {
			  
			  aux=s.replace("*","");
			  System.out.println("AUX "+aux);
			  aux=aux.replace("?","");
		
			  System.out.println("AUX "+aux);
			  return aux;
		  }

	}
	public ArrayList<String> getNumTranslit1() {
		return ntr1;
	}
	public void generateNT1() {
		ArrayList<NumTranslit1> nt1=new ArrayList<NumTranslit1>();
		int nr=0;
		NumTranslit1 n1 = new NumTranslit1(id+">"+"NT1_0",interf);
		nt1.add(n1);
		for (int i=0;i<elemNodes.size();i++) {
			int na=0;
			if (elemNodes.get(i).getAlternatives().isEmpty()) {
				for (int j=0;j<nt1.size();j++) {
					NT1Element x=new NT1Element(elemNodes.get(i));
					elemNodes.get(i).getNT1Elements().add(x);
				nt1.get(j).getElements().add(x);
				}
			}
			else {
				ArrayList<NT1Element> elx=new ArrayList<NT1Element>();
				for (Map.Entry<String, ArrayList<Reading>> entry : elemNodes.get(i).getAlternatives().entrySet()) 
				    elx.add(new NT1Element(elemNodes.get(i),entry.getKey()));
				ArrayList<NumTranslit1> nt1aux=new ArrayList<NumTranslit1>();
				System.out.println("1 NT1 Elem "+ elx.get(0).getLabel());
		        for (int k=0;k<nt1.size();k++) {
		        	NumTranslit1 nx=nt1.get(k).copy();
		        	nx.getElements().add(elx.get(0));
		        	nt1aux.add(nx);
		        }
		        for(int l=1;l<elx.size(); l++) {
		        	System.out.println("NT1 Elem "+ elx.get(l).getLabel());
		        	for(int k=0;k<nt1.size();k++) {
		        		nr=nr+1;
		        		NumTranslit1 nx=nt1.get(k).copy();
		        		nx.setId(id+">"+"NT1_"+nr);
		        		nx.getElements().add(elx.get(l));
		        	//	System.out.println(nx.calculateLabel());
		        		nt1aux.add(nx);
		        	}
		        }
		        
		         nt1.clear();
		         for (int k=0;k<nt1aux.size();k++) {
		        	 nt1.add(nt1aux.get(k));
		         }     
		       
			}
		}
		for (int i=0;i<nt1.size();i++) {
			ntr1.add(nt1.get(i).getId());
			
			interf.nt1.add(nt1.get(i));
			interf.mnt1.put(nt1.get(i).getId(),new Integer(interf.nt1.size()-1));
			nt1.get(i).generateNT2();
		}
	}
/*	public void setNtr1(String s) {
		ntr1=s;
	}*/

}
