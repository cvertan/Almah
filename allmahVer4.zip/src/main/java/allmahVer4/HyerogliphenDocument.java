package allmahVer4;
import java.util.ArrayList;
import java.lang.Integer;
public class HyerogliphenDocument extends TreeNode {

	private String title;
	private String id;
	private boolean state;
	private ArrayList<String> b;
	private AllmahGUI interf;
	public HyerogliphenDocument( String num, AllmahGUI interf) {
		super(0);
		this.id=num;
		state=true;
		this.interf=interf;
		b=new ArrayList<String>();
	}
	public String calculateLabel() {
		return id;
	}
	public boolean getState() {
		return state;
	}
	public void setState(boolean b) {
		state=b;
	}
	public String getParent() {
		return null;
	}
	 public  ArrayList<TreeNode> listNodes(){
		 ArrayList <TreeNode> t=new ArrayList<TreeNode>();
		 for(int i=0;i<b.size();i++) {
			 t.add(interf.docr.get(interf.mdocr.get(b.get(i)).intValue()));
		 }
		 return t;
	 }	
	 public String getTitle() {
		return title;
	}
	public String getId() {
		return id;
	}
	
	public void setId(String s) {
		id=s;
	}
	
	public ArrayList<String> getDocReadings() {
		return b;
	}
	public void setDocumentReadings(ArrayList<String> bid) {
		for(int i=0;i<bid.size();i++)
               b.add(bid.get(i));
	}


}
