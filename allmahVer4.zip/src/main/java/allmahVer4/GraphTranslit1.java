package allmahVer4;
import java.util.ArrayList;
import java.util.Map;

public class GraphTranslit1 extends TreeNode {
	String id;
	ArrayList<GT1Element> elem;
	ArrayList<String> compon;
	ArrayList<String> gt2;
	AllmahGUI tag;
	public GraphTranslit1(String id,AllmahGUI tag) {
		super(3);
		this.id=id;
		elem=new ArrayList<GT1Element>();
		compon=new ArrayList<String>();
		gt2=new ArrayList<String>();
		this.tag=tag;
	}
	public String calculateLabel() {
		String aux=""; int n=0;
		NumTranslit2 n2=tag.nt2.get((tag.mnt2.get(this.getParent())).intValue());
		NumTranslit1 n1=tag.nt1.get((tag.mnt1.get(n2.getParent())).intValue());
		ArrayList<Object> o=tag.hb.get((tag.mhb.get(n1.getParent())).intValue()).getTeile();
		for (int i=0;i<o.size();i++) {
			//System.out.println("Object class Name "+ o.getClass().getName());
			if(o.get(i).getClass().getName().contains("Glyph")) {
				aux=aux+elem.get(n).getLabel();n=n+1;
			}
			else if(o.get(i).getClass().getName().contains("Operator")) {
				aux=aux+((OperatorLink)o.get(i)).toString();
			}
			else aux=aux+o.get(i).toString();
		}
		return aux;
	}
	
	public ArrayList<String> getCompon(){
		return compon;
	}
	public GraphTranslit1 copy() {
		GraphTranslit1 aux=new GraphTranslit1(id,tag);
		for (int i=0;i<this.elem.size();i++) {
			aux.getElements().add(elem.get(i));
		}
		return aux;
	}
	public String getParent() {
		return id.substring(0,id.lastIndexOf(">"));
	}
	public void setId(String s) {
		this.id=s;
	}

	
	public String getId() {
		return id;
	}
	public AllmahGUI getTagInterf() {
		return tag;
	}
	

	public  ArrayList<TreeNode> listNodes(){
		 ArrayList <TreeNode> t=new ArrayList<TreeNode>();
		 if(gt2.size()>0) {
		 for(int i=0;i<gt2.size();i++) {
		//	 t.add(tag.num2.get(Integer.parseInt(tag.mapnum2.get(nt2.get(i)))));
		 }
		 }
		 return t;
	 }
	public ArrayList<GT1Element> getElements(){
		return elem;
	}
	public void setGT1Elements(ArrayList<GT1Element>n2) {
		for (int i=0;i<n2.size();i++ ) {
			elem.add(n2.get(i));
		}
	}
	

}

